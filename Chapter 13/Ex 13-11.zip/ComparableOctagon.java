public class ComparableOctagon extends Octagon implements Cloneable, Comparable<GeometricObject>{

public int compareTo(Octagon o) {
        if (getArea() > o.getArea())
        return 1;
        else if (getArea() < o.getArea())
        return -1;
        else
        return 0;
        }
}
