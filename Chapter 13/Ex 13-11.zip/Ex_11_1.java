import java.awt.*;
import java.util.Scanner;

public class Ex_11_1 {

	public static void main(String[] args) throws CloneNotSupportedException{
			/**Scanner scanner = new Scanner(System.in);
			Triangle[] triangle = new Triangle[5];
			for (int i = 0; i < triangle.length; i++) {
				System.out.println("Enter the sides of the triangle, the color and if it is filled or not: ");
				double side1 = scanner.nextDouble();
				double side2 = scanner.nextDouble();
				double side3 = scanner.nextDouble();
				String color = scanner.next();
				boolean isFilled = scanner.nextBoolean();



				try {
					triangle[i] = new Triangle(side1, side2, side3, color, isFilled);
				} catch (IllegalTriangleException ite) {
					System.out.println(ite.toString());
				}
			}
			for (int i = 0; i < triangle.length; i++) {
				System.out.println(triangle[i].toString());
				System.out.printf("Triangle color: %s, Triangle filled: %s%n" +
								"Area: %.2f%n" +
								"Perimeter: %.2f%n%n",
						triangle[i].getColor(),
						triangle[i].isFilled(),
						triangle[i].getArea(),
						triangle[i].getPerimeter());
						triangle[i].howToColor();

			}**/


		// Create an Octagon object
		Octagon octagon1 = new Octagon(5);

		// Display area and perimeter of object
		System.out.println("\nOctagon:\nArea: " + octagon1.getArea() +
				"\nPerimeter: " + octagon1.getPerimeter());

		// Create new object using the clone method

		System.out.println("Cloning Octagon...");
		Octagon octagon2 = (Octagon)octagon1.clone();

		// Compare the two object using compareTo method
		int result = (octagon1.compareTo(octagon2));
		if (result == 1)
			System.out.println("Octagon is greater than its clone.");
		else if (result == -1)
			System.out.println("Octagon is less than its clone.");
		else
			System.out.println("Octagon is equal to its clone.");
	}
}
