import java.awt.*;
import java.util.Scanner;

public class Ex_11_1 {

	public static void main(String[] args) {
			Scanner scanner = new Scanner(System.in);
			Triangle[] triangle = new Triangle[5];
			for (int i = 0; i < triangle.length; i++) {
				System.out.println("Enter the sides of the triangle, the color and if it is filled or not: ");
				double side1 = scanner.nextDouble();
				double side2 = scanner.nextDouble();
				double side3 = scanner.nextDouble();
				String color = scanner.next();
				boolean isFilled = scanner.nextBoolean();



				try {
					triangle[i] = new Triangle(side1, side2, side3, color, isFilled);
				} catch (IllegalTriangleException ite) {
					System.out.println(ite.toString());
				}
			}
			for (int i = 0; i < triangle.length; i++) {
				System.out.println(triangle[i].toString());
				System.out.printf("Triangle color: %s, Triangle filled: %s%n" +
								"Area: %.2f%n" +
								"Perimeter: %.2f%n%n",
						triangle[i].getColor(),
						triangle[i].isFilled(),
						triangle[i].getArea(),
						triangle[i].getPerimeter());
						triangle[i].howToColor();

			}
	}
}
