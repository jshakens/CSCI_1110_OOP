public class Ex_9_1 {

    public static void main(String[] args) {
    Rectangle one;
    one = new Rectangle();
    one.Rectangle(4,40);
    one.getArea();
    one.getPerimeter();
    Rectangle two;
    two = new Rectangle();
    two.Rectangle(3.5, 35.9);
    two.getArea();
    two.getPerimeter();
    }
}
